package com.example.demo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;

@Entity
public class Teacher extends Staff {
	private String subject;
	
	 @OneToMany(mappedBy = "teacher")
	 @JsonManagedReference
	    private List<Course> courses;

	
	 @OneToMany(mappedBy = "teacher")
	 @JsonManagedReference
	    private List<Exam> exams;

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

	public List<Exam> getExams() {
		return exams;
	}

	public void setExams(List<Exam> exams) {
		this.exams = exams;
	}
}

