package com.example.demo.repository;
import com.example.demo.GradeLevel;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface GradeLevelRepository extends JpaRepository<GradeLevel, Long> {
	List<GradeLevel> findByNameContainingIgnoreCase(String namePart);
}
