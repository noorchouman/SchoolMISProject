package com.example.demo.repository;

import com.example.demo.Exam;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExamRepository extends JpaRepository<Exam, Long> {
	List<Exam> findByCourseId(Long courseId);
 
	Page<Exam> findByCreatedAtAfter(LocalDateTime date, Pageable pageable);
}
