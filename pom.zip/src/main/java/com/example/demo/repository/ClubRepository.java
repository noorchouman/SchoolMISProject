package com.example.demo.repository;

import com.example.demo.Club;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ClubRepository extends JpaRepository<Club, Long> {

	List<Club> findByNameContainingIgnoreCase(String name);

	List<Club> findByMembersId(Long memberId);
}
