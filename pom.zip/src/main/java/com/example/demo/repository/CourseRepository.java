package com.example.demo.repository;

import com.example.demo.Course;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Long>{
	List<Course> findByTeacherId(Long teacherId);

    List<Course> findByGradeLevelId(Long gradeLevelId);

    List<Course> findByCourseNameContainingIgnoreCase(String courseName);
}
